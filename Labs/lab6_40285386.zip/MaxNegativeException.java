public class MaxNegativeException {
    public void printMessage() {
        System.out.println("Maximum value is negative");
    }
}