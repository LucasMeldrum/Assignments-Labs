public class Driver {

    public static void main(String[] args) {
        int[] data1Array = {10, 20, -30, 40, 50};
        MaximumFinder data1 = new MaximumFinder(data1Array, 0, 4);
        int[] data2Array = {5, 10, 15, 20, 25};
        MaximumFinder data2 = new MaximumFinder(data2Array, 1, 4);
        int[] data3Array = {2, 3, 5, -7, 11};
        MaximumFinder data3 = new MaximumFinder(data3Array, 2, 4);
        int[] data4Array = {4, 5, 6, 7, 8};
        MaximumFinder data4 = new MaximumFinder(data4Array, 1, 3);
        int[] data5Array = {1, 2, 3, 4, 5};
        MaximumFinder data5 = new MaximumFinder(data5Array, 0, 4);

        System.out.println(data1.find_maximum());
        System.out.println(data2.find_maximum());
        System.out.println(data3.find_maximum());
        System.out.println(data4.find_maximum());
        System.out.println(data5.find_maximum());
    }
}
