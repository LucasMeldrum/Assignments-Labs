public class MaximumFinder {
    protected int[] data;
    protected int startindex;
    protected int endindex;

    public MaximumFinder(int[] data, int startindex, int endindex) {
        this.data = data;
        this.startindex = startindex;
        this.endindex = endindex;
    }

    public int find_maximum() {
        if (startindex < 0 || startindex >= data.length || endindex < 0 || endindex > data.length || startindex >= endindex) {
            throw new IllegalArgumentException("Invalid start or end index");
        }

        int max = data[startindex];

        for (int i = startindex + 1; i < endindex; i++) {
            if (data[i] > max) {
                max = data[i];
            }
        }

        if (max == 0) {
            ZeroMaximumException zeroMaxException = new ZeroMaximumException();
            zeroMaxException.printMessage();
        } else if (max < 0) {
            MaxNegativeException maxNegException = new MaxNegativeException();
            maxNegException.printMessage();
        }
        
       
            
        
		return max;
		
    }

    

   
}
