public class ZeroMaximumException {
    public void printMessage() {
        System.out.println("Maximum value is zero");
    }
}