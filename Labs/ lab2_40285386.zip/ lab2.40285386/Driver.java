
public class Driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Restaurant rest1 =  new Restaurant("McDonalds", "Montreal", 2.3, 12.3);
		 
		 Restaurant rest2 =  new Restaurant("Subway", "Cote-St-Luc", 4.4, 15.2);
		 
		 Restaurant rest3 =  new Restaurant("Wendys", "Laval", 4.7, 9.2);
		 
		 System.out.print(rest1.visitOrNot());
		 System.out.print(rest2.visitOrNot());
		 System.out.print(rest3.visitOrNot());
		 
		 System.out.print(rest1.displayRating(rest2));
	               
	              
	}

}
