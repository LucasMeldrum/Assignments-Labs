
public class Restaurant {
	
private String name;
private String location;
private Double rating;
private Double averageItemPrice;

public Restaurant() {  
	this.name = "";
	this.location = "";
	this.rating = 0.0;
	this.averageItemPrice = 0.0;
}


public Restaurant(String name, String location, Double rating, Double averageItemPrice) {
	this.name = name;
	this.location = location;
	this.rating = rating;
	this.averageItemPrice = averageItemPrice;
	
}

public Restaurant(Restaurant copy) {
	this.name = copy.name;
	this.location = copy.location;
	this.rating = copy.rating;
	this.averageItemPrice = copy.averageItemPrice;
}
public void setName(String name) {
	this.name = name;
}

public void setLocation(String location) {
	this.location = location;
}

public void setRating(Double rating) {
	this.rating = rating;
}
public void setAverageItemPrice(Double averageItemPrice) {
	this.averageItemPrice = averageItemPrice;
}
public String getName() {
	return this.name;
}
public String getLocation() {
	return this.location;
}
public Double getRating() {
	return this.rating;
}
public Double getaverageItemPrice() {
	return this.averageItemPrice;
}
public String visitOrNot() {
	if (this.rating>3.5) {
		return "Recommended";
	}
	else return null;
}
public String displayRating(Restaurant otherRestaurant) {
	if (this.rating > otherRestaurant.rating) {
		for (int x =0; rating < 0; rating--)
			return "*" + "";
}
	else {
		for (int x =0; otherRestaurant.rating < 0; otherRestaurant.rating--) 
			return "*" + ""; }
	
		
}

public void quality() {
	double averagePriceOfMeal = (3*averageItemPrice) - 10;
	double quality = (rating*averagePriceOfMeal)/20;
}
public boolean equals(Restaurant otherRestaurant) {
	return this.location == otherRestaurant.location && this.name == otherRestaurant.name;
}
public String toString() {
	return this.name + "is located on " + this.location + " and has a rating of " + this.rating;
	
}
public static Object bestRestaurant(String Restaurant[], String otherRestaurant[]) {
	if (this.rating > otherRestaurant.rating) {
		return Restaurant;
	}
	else {
		return otherRestaurant;
	}
}
}