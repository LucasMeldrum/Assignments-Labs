
public class Driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Employee[] employees = new Employee[5];
		 
		employees[0] = new Programmer();
		employees[1] = new Programmer();
		employees[2] = new Accountant(0, null, null);
		employees[3] = new Accountant();
		employees[4] = new Programmer();
		
		System.out.print(Programmer.develop());
		System.out.print(Accountant.calculate());
	}
	}

