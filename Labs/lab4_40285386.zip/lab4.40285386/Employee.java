
public class Employee {

	
protected int vacationDays;
protected Double hours;
protected Double salary;

public Employee() {  
	this.vacationDays = 0;
	this.hours = 0.0;
	this.salary = 0.0;
}


public Employee(int vacationDays, Double hours, Double salary) {
	this.vacationDays = vacationDays;
	this.hours = hours;
	this.salary = salary;
	
}
public int getVacationDays() {
	return this.vacationDays;
}

public Double getHours() {
	return this.hours;
}

public Double getSalary() {
	return this.salary;
}
}