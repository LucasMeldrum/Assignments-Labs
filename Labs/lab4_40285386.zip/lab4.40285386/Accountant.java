
public class Accountant extends Employee {

	public Accountant(int vacationDays, Double hours, Double salary) {
        super(vacationDays, hours, salary);
}
	public Accountant() {
		
	}
	public static String calculate() {
		return "Performing financial calculations";
	}
	
	public void setHours(double hours) {
		this.hours = 40.0;
	}
	public void setSalary(double salary) {
		this.salary = 70000.0;
	}
	public void setVacationDays(int vacationDays) {
		this.vacationDays = 10;
	}
}
