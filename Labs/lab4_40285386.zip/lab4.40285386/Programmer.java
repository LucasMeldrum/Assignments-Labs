
public class Programmer extends Employee {

	public Programmer(int vacationDays, Double hours, Double salary) {
        super(vacationDays, hours, salary);
}
public Programmer() {
		
	}
public static String develop() {
	return "Developing new Software";
}
public void setSalary(Double salary) {
	this.salary = 100000.00;
}

}
