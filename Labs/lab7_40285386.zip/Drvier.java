
public class Drvier {

	
	    public static void main(String[] args) {
	        // Create a Book object
	        Book book = new Book("Java Programming", "John Doe", "10", 2022, "Programming");

	        // Create a ClassHandler object
	        ClassHandler handler = new ClassHandler(book, "book_details.txt");

	        // Write book details to file
	        handler.writeToFile("book_details.txt");

	        // Read book details from file
	        Book readBook = handler.readFromFile("book_details.txt");

	        // Display read book details
	        if (readBook != null) {
	            System.out.println("Read Book: \n" + readBook);
	        } else {
	            System.out.println("Failed to read book details from file.");
	        }
	    }
	}


