import java.io.FileWriter;
import java.io.FileReader;
import java.io.IOException;
import java.io.BufferedReader;
import java.io.BufferedWriter;

public class ClassHandler {
	public Book book;
	public String path;
	
	public ClassHandler(Book book, String path) {
		this.book = book;
		this.path = path;
	}
	public void writeToFile(String path) {
		
		try {
            FileWriter writer = new FileWriter(path);

            // Writing book details to the file
            writer.write("Title: " + book.getTitle() + "\n");
            writer.write("Author: " + book.getAuthor() + "\n");
            writer.write("ISBN: " + book.getISBN() + "\n");
            writer.write("YearOfPublcation: " + book.getPublicationYear() + "\n");
            writer.write("Genre: " + book.getGenre() + "\n");
           
           

            writer.close();
            System.out.println("Book details have been written to " + path);
        } 
		
		catch (IOException e) {
            System.out.println("An error occurred while writing the book details to file: " + e.getMessage());
            e.printStackTrace();
        }
		
    }
	
	public Book readFromFile(String path) {
		
		try (BufferedReader reader = new BufferedReader(new FileReader(path))) {
	        String title = reader.readLine();
	        String author = reader.readLine();
	        String ISBN = reader.readLine();
	        String publicationYearLine = reader.readLine(); // Read the line containing publication year
	        int publicationYear = Integer.parseInt(publicationYearLine.split(": ")[1]); // Extract and parse the numeric part after ": "
	        String genre = reader.readLine(); // Read Genre
	        return new Book(title, author, ISBN, publicationYear, genre);
	    } catch (IOException e) {
	        System.out.println("An error occurred while reading the file: " + e.getMessage());
	        e.printStackTrace();
	    }
	    return null; // Return null if there's an error
	}


		
		
	}


