
public class Book {
	public String Title;
	public String Author;
	public String ISBN;
	public int PublicationYear;
	public String Genre;
	
	public Book(String Title, String Author, String ISBN, int PublicationYear, String Genre) {
		this.Title = Title;
		this.Author = Author;
		this.ISBN = ISBN;
		this.PublicationYear = PublicationYear;
		this.Genre = Genre;
	}
	
	//Accessors 
    public String getTitle() {
    	return this.Title;
    }
    public String getAuthor() {
    	return this.Author;
    }
    public String getISBN() {
    	return this.ISBN;
    }
    public int getPublicationYear() {
    	return this.PublicationYear;
    }
    public String getGenre() {
    	return this.Genre;
    }
    
    //Mutators
    public void setTitle(String Title) {
    	this.Title = Title;
    }
    public void setAuthor(String Author) {
    	this.Author = Author;
    }
    public void setISBN(String ISBN) {
    	this.ISBN = ISBN;
    }
    public void setPublicationYear(int PublicationYear) {
    	this.PublicationYear = PublicationYear;
    }
    public void setGenre(String Genre) {
    	this.Genre = Genre;
    }
    
    //toString() method
    @Override
    public String toString() {
        return "Title: " + Title + "\n Author: " + Author + "\n ISBN: " + "\n Year of Publication: " + PublicationYear + "\n Genre: " + Genre;
    }

  
}

