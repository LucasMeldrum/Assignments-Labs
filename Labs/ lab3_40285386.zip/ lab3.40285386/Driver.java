
public class Driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i = 0;
		 Bird[] birds = new Bird[5];
		 
		 birds[0] = new Pigeon(true, 5.0, 3.0);
		 birds[1] = new Pigeon(true, 2.0, 5.0);
		 birds[2] = new Pigeon(true, 0.34, 0.5);
		 birds[3] = new Penguin(false, 5.0, 3.0);
		 birds[4] = new Penguin(false, 0.7, 5.2);
		
		 
		 for (int x = 0; x < 5; x++)
			 if (birds[x].getcanFly())
			 {
			 System.out.print(birds[x].goodHeightWeightRatio());
			 }
			 else 
				 System.out.print("\nThis bird can't fly");
			 
		 for (int x = 0; x < 5; x++)
			 System.out.print(birds[x].toString());
			 
		 for (int x = 0; x < 5; x++)
			 if (birds[x].getcanFly())
				 if (birds[x].goodHeightWeightRatio())
					 i = i+1;
					 System.out.print("\n" + i);
	}

}
