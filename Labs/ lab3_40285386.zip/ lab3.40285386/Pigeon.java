
public class Pigeon extends Bird {
	
	public Pigeon(Boolean canFly, Double height, Double weight) {
        super(canFly, height, weight);
    }

	
	public Boolean goodHeightWeightRatio() {
		if ((this.weight/(this.height*this.height) > 3) && (this.weight/(this.height*this.height) < 5))
			return true;
		
		else
			return false;
	}
	
	public String toString() {
		return "\nHello I'm a piegeon" + "\nBird can fly: " + this.canFly + "\nHeight: " + this.height + "\nWeight: " + this.weight;
	}
}