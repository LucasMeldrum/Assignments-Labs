
public class Penguin extends Bird {
	
	public Penguin(Boolean canFly, Double height, Double weight) {
        super(canFly, height, weight);
    }
	public void setcanFly(Boolean canFly) {
		this.canFly = false;
	}
	
	
	
	public String toString() {
		return "\nHello I'm a penguin" + "\nBird can fly: " + this.canFly + "\nHeight: " + this.height + "\nWeight: " + this.weight;
	}
}
