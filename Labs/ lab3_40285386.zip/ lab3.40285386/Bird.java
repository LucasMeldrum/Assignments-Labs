
public class Bird {
	
protected Boolean canFly;
protected Double height;
protected Double weight;

public Bird() {  
	this.canFly = null;
	this.height = 0.0;
	this.weight = 0.0;
}


public Bird(Boolean canFly, Double height, Double weight) {
	this.canFly = canFly;
	this.height = height;
	this.weight = weight;
	
}public Boolean goodHeightWeightRatio() {
	if ((this.weight/(this.height*this.height) > 8) && (this.weight/(this.height*this.height) < 13))
		return true;
	
	else
		return false;
	
}
public String toString() {
	return "Bird can fly: " + this.canFly + "\nHeight: " + this.height + "\nWeight: " + this.weight;
}
public Boolean getcanFly () {
	return this.canFly;
}
}


