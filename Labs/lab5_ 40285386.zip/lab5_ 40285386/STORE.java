public abstract class STORE {
  
	protected String location;
	protected String nameOfStore;
	protected Double salesTax;

	public STORE() {  
		this.location = "";
		this.nameOfStore = "";
		this.salesTax = 0.0;
	
	}
	
public STORE(String location, String nameOfStore, Double salesTax) {
	this.location = location;
	this.nameOfStore = nameOfStore;
	this.salesTax = salesTax;
}
public void setLocation(String location) {
	this.location = location;
}

public void setName(String nameOfStore) {
	this.nameOfStore = nameOfStore;
}
public void setAverageItemPrice(Double salesTax) {
	this.salesTax = salesTax;
}
public String getlocation() {
	return this.location;
}
public String nameOfStore() {
	return this.nameOfStore;
}
public Double salesTax() {
	return this.salesTax;
}
public String toString() {
	return this.nameOfStore + "is located on " + this.location + " and has a sales tax of " + this.salesTax;
	


}

	public abstract Double TotalPrice();

	

	public abstract String information();
	
}