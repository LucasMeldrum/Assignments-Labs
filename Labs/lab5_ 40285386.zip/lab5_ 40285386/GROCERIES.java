
public class GROCERIES extends STORE {

    public GROCERIES(String location, String nameOfStore, Double salesTax) {
        super(location, nameOfStore, salesTax);
    }
    
	public GROCERIES() {
		// TODO Auto-generated constructor stub
	}
	private Double priceOfGroceries;
    private Boolean organic;
    
	 public Double getPriceOfGroceries() {
	        return priceOfGroceries;
	    }

	    public void setPriceOfGroceries(Double priceOfGroceries) {
	        this.priceOfGroceries = priceOfGroceries;
	    }

	    public Boolean getorganic() {
	        return organic;
	    }

	    public void setorganic(Boolean organic) {
	        this.organic = organic;
	    }
	
	public String toString() {
		return this.nameOfStore + "is located on " + this.location + " and has grocery price of " + this.priceOfGroceries;
	}

	@Override
	public Double TotalPrice() {
		// TODO Auto-generated method stub
		return organic ? priceOfGroceries*1.15*salesTax : priceOfGroceries*salesTax;
	}

	@Override
	public String information() {
		// TODO Auto-generated method stub
		return "The store " + this.nameOfStore + " which is located at " + this.location + " city has  " + this.priceOfGroceries + " on groceries and they also charge " + this.salesTax + " as sales tax";
	}

}
