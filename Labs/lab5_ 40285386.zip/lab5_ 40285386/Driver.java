
public class Driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		STORE[] stores = new STORE[6];
		 
		int x;
		
		 stores[0] = new ELECTRONICS("location1", "Store1", 0.7);
		 ((ELECTRONICS) stores[0]).setPriceOfElectronics(10.0);
		 ((ELECTRONICS) stores[0]).setNumberOfElectronics(25);
		 
		 stores[1] = new GROCERIES("location2", "Store2", 0.3);
		 ((GROCERIES) stores[4]).setPriceOfGroceries(4.0);
		 ((GROCERIES) stores[4]).setorganic(true);
		 
		 stores[2] = new GROCERIES("location3", "Store3", 0.05);
		 ((GROCERIES) stores[4]).setPriceOfGroceries(4.0);
		 ((GROCERIES) stores[4]).setorganic(false);

		 
		 stores[3] = new GROCERIES("location4", "Store4", 0.15);
		 ((GROCERIES) stores[4]).setPriceOfGroceries(7.0);
		 ((GROCERIES) stores[4]).setorganic(true);

		 
		 stores[4] = new ELECTRONICS("location5", "Store5", 0.24);
		 ((ELECTRONICS) stores[4]).setPriceOfElectronics(11.0);
		 ((ELECTRONICS) stores[0]).setNumberOfElectronics(10);
		 
		 stores[5] = new ELECTRONICS("location6", "Store6", 0.1);
		 ((ELECTRONICS) stores[5]).setPriceOfElectronics(13.0);
		 ((ELECTRONICS) stores[0]).setNumberOfElectronics(55);
	
	 for (x = 0; x < 5; x++)
		 System.out.print("\n");
		 System.out.print(stores[x].information());
		 System.out.print("\n");
	 	 System.out.print(stores[x].TotalPrice());
	 		
}
}