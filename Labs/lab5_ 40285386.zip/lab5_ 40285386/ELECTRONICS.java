public class ELECTRONICS extends STORE {
    private Double priceOfElectronics;
    private int numberOfElectronics;

    public ELECTRONICS(String location, String nameOfStore, Double salesTax) {
        super(location, nameOfStore, salesTax);
    }

    public Double getPriceOfElectronics() {
        return priceOfElectronics;
    }

    public void setPriceOfElectronics(Double priceOfElectronics) {
        this.priceOfElectronics = priceOfElectronics;
    }

    public int getNumberOfElectronics() {
        return numberOfElectronics;
    }

    public void setNumberOfElectronics(int numberOfElectronics) {
        this.numberOfElectronics = numberOfElectronics;
    }

    
    public String toString() {
    	return this.priceOfElectronics + " is the cost\n " + this.numberOfElectronics + " is the amount";
    	
    }
    @Override
    public Double TotalPrice() {
    	return (numberOfElectronics >5)? priceOfElectronics * numberOfElectronics + 10 : priceOfElectronics * numberOfElectronics * this.salesTax +10;
    	
    }
    @Override
    public String information() {
     	return "The store " + this.nameOfStore + " which is located at " + this.location + " city has " + this.numberOfElectronics + " different kinds of electronics and they also charge " + this.salesTax + " as sales tax";
    }
    	
}
